package com.example.ProyectoIntegrador.repository;


import com.example.ProyectoIntegrador.entity.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TurnoRepository extends JpaRepository<Turno,Long> {
}
